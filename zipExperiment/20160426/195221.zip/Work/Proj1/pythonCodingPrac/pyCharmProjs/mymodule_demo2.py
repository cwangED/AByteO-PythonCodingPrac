#!/usr/bin/python
# Filename: mymodule_demo2.py

from mymodule import sayhi, version

sayhi()
print 'Version', version
print 'module __name__ is: ', __name__
