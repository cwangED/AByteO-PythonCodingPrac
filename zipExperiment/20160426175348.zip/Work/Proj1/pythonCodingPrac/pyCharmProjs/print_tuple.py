#!/usr/bin/python
# Filename: print_tuple.py

age = 22
name = 'Swaroop'

print "%s is %d years old" % (name, age)
print 'Why is % s playing with that python?' % name