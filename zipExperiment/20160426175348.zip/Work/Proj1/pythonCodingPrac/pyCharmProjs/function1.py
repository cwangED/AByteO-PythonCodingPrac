#!/usr/bin/python
# Filename: function1.py

def sayHello():
    print 'Hello World!'

sayHello()